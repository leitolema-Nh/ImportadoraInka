<?php
$title = "Cozastore - Home";
$activePage = "home";
include __DIR__ . '/../partials/header.php';
?>

<!-- 👇 TODO el contenido central del index que pegaste va aquí -->
<?php include __DIR__ . '/../partials/slider.php'; ?>
<?php include __DIR__ . '/../partials/product-section.php'; ?>
<!-- puedes seguir dividiendo el contenido en más partials -->

<?php
include __DIR__ . '/../partials/footer.php';
?>
