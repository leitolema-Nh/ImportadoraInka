<?php
// ============================================
// 🌍 LAYOUT.PHP — Estructura global del sitio
// Totalmente independiente del nombre de carpeta
// ============================================

// Incluir configuración global
$config = include __DIR__ . '/../config/config.php';

// Detectar URL base
$base = $config['paths']['baseURL'] ?? '/';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle ?? 'Catálogo Inka Import') ?></title>

  <!-- ✅ CONFIG GLOBAL - PRIMERO -->
  <script src="<?= $base ?>js/config.js.php"></script>

  <!-- ================= CSS CORE ================= -->
  <link rel="stylesheet" href="<?= $base ?>vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/animate/animate.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/css-hamburgers/hamburgers.min.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/animsition/css/animsition.min.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/select2/select2.min.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/slick/slick.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/MagnificPopup/magnific-popup.css">
  <link rel="stylesheet" href="<?= $base ?>vendor/perfect-scrollbar/perfect-scrollbar.css">

  <!-- ================= CSS SITE ================= -->
  <link rel="stylesheet" href="<?= $base ?>fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= $base ?>fonts/iconic/css/material-design-iconic-font.min.css">
  <link rel="stylesheet" href="<?= $base ?>css/util.css">
  <link rel="stylesheet" href="<?= $base ?>css/main.css">
  <link rel="stylesheet" href="<?= $base ?>css/header.css">
  <link rel="stylesheet" href="<?= $base ?>css/products.css">
  <link rel="stylesheet" href="<?= $base ?>css/search-overlay.css">

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="<?= $base ?>images/icons/favicon.png">
</head>

<body class="animsition">
  <?php include __DIR__ . '/../partials/header.php'; ?>

  <main class="main-content">
    <?php
      if (!empty($contentFile) && file_exists($contentFile)) {
        include $contentFile;
      } else {
        echo "<div class='container py-5 text-center'><h2>⚠️ Página no encontrada</h2></div>";
      }
    ?>
  </main>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
