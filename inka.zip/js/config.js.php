<?php
/**
 * 📱 config.js.php — Configuración JavaScript dinámica
 * Genera el objeto window.CONFIG con rutas correctas según el entorno
 */

header("Content-Type: application/javascript; charset=UTF-8");

// ✅ Cargar configuración global (que ya detecta el entorno)
$config = include __DIR__ . '/../config/config.php';
$env = $config['env'] ?? 'dev';
$paths = $config['paths'] ?? [];

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

// Usar la detección ya hecha en config.php
$isLocal = ($env === 'dev');

$scriptPath = $_SERVER['SCRIPT_NAME'] ?? '/';
$scriptPath = str_replace('\\', '/', $scriptPath);
$parts = explode('/', trim($scriptPath, '/'));
$projectFolder = $isLocal ? ($parts[0] ?? '') : '';
$baseFolder = $projectFolder ? '/' . $projectFolder . '/' : '/';
$baseURL = $protocol . $host . $baseFolder;

$filesPath  = ($env === 'prod') ? $baseURL . 'catalogo/files/' : $baseURL . 'files/';
$imagesPath = $baseURL . 'images/';
$apiURL     = $baseURL . 'api/';

// =============================
// 🚀 GENERAR OBJETO CONFIG
// =============================
?>
// 🔧 Configuración global generada dinámicamente
window.CONFIG = <?= json_encode([
  'environment' => $env,
  'baseURL'     => $baseURL,
  'apiURL'      => $apiURL,
  'imagesPath'  => $imagesPath,
  'filesPath'   => $filesPath
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) ?>;

<?php if ($env === 'dev'): ?>
// 📱 Log de debug (solo en desarrollo)
console.log('✅ CONFIG.js cargado');
console.log('   🌍 Entorno: <?= $env ?>');
console.log('   🔗 BaseURL: <?= $baseURL ?>');
console.log('   📡 API URL: <?= $apiURL ?>');
console.log('   📱 Host detectado: <?= $host ?>');
<?php endif; ?>